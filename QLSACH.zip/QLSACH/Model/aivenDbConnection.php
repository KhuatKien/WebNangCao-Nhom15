<?php

$uri = "mysql://avnadmin:AVNS_XnePfh9KpmYWJWgSNHo@mysql-web-khuatkien-web.d.aivencloud.com:16884/defaultdb?ssl-mode=REQUIRED";

$fields = parse_url($uri);

// build the DSN including SSL settings
$conn = "mysql:";
$conn .= "host=" . $fields["host"];
$conn .= ";port=" . $fields["port"];;
$conn .= ";dbname=QUANLYSACH";
$conn .= ";sslmode=verify-ca;sslrootcert='pri/ca.pem'";

try {
    $db = new PDO($conn, $fields["user"], $fields["pass"]);
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}