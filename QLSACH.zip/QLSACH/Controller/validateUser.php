<?php
session_start();
require_once '/xampp/htdocs/Project/WebNangCao-Nhom15/QLSACH/Model/aivenDbConnection.php';

$_SESSION['isLogin'] = false;

if($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Mã hóa mật khẩu trước khi truy vấn vào cơ sở dữ liệu
    $hashed_password = hash('sha256', $password); // Sử dụng hàm băm SHA-256 hoặc một hàm băm khác

    // Truy vấn CSDL để kiểm tra thông tin đăng nhập
    $query = "SELECT * FROM User WHERE TenUser = :username AND MatKhau = :password";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $hashed_password); // Sử dụng mật khẩu đã mã hóa
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if($user) {
        // Đăng nhập thành công, lưu thông tin người dùng vào session
        $_SESSION['userId'] = $user['MaUser'];
        $_SESSION['username'] = $user['TenUser'];
        header("Location: /QLSACH/View/sach.php"); // Chuyển hướng đến trang "Sach"
        exit();
    } else {
        $error = "Tên người dùng hoặc mật khẩu không đúng.";
        header("Location: /QLSACH/View/login.html?error=$error"); // Chuyển hướng người dùng trở lại trang đăng nhập với thông báo lỗi
        exit();
    }
}
?>