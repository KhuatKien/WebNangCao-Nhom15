<?php
session_start();

// Hủy toàn bộ phiên làm việc
$_SESSION = array();

// Hủy các cookie liên quan đến phiên làm việc nếu có
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Hủy toàn bộ phiên làm việc
session_destroy();

// Chuyển hướng người dùng về trang đăng nhập sau khi đăng xuất
header("Location: /QLSACH/View/login.html");
exit();
?>