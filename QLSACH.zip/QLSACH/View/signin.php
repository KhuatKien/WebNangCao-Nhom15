<?php
session_start();
require_once '/xampp/htdocs/Project/WebNangCao-Nhom15/QLSACH/Model/aivenDbConnection.php';

if($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Mã hóa mật khẩu trước khi lưu vào cơ sở dữ liệu
    $hashed_password = hash('sha256', $password); // Sử dụng hàm băm SHA-256 hoặc một hàm băm khác

    // Truy vấn SQL để kiểm tra xem tên người dùng đã tồn tại chưa
    $check_query = "SELECT * FROM User WHERE TenUser = :username";
    $check_stmt = $db->prepare($check_query);
    $check_stmt->bindParam(':username', $username);
    $check_stmt->execute();
    $existing_user = $check_stmt->fetch(PDO::FETCH_ASSOC);

    if($existing_user) {
        $error = "Tên người dùng đã tồn tại.";
        header("Location: /QLSACH/View/register.html?error=$error"); // Chuyển hướng người dùng trở lại trang đăng ký với thông báo lỗi
        exit();
    } else {
        // Thêm người dùng mới vào cơ sở dữ liệu
        $insert_query = "INSERT INTO User (TenUser, MatKhau) VALUES (:username, :password)";
        $insert_stmt = $db->prepare($insert_query);
        $insert_stmt->bindParam(':username', $username);
        $insert_stmt->bindParam(':password', $hashed_password); // Lưu mật khẩu đã mã hóa
        $insert_stmt->execute();

        // Đăng ký thành công, chuyển hướng đến trang đăng nhập
        header("Location: /QLSACH/View/login.html");
        exit();
    }
}
?>