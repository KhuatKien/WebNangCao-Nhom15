<?php
session_start();
require_once '/xampp/htdocs/Project/WebNangCao-Nhom15/QLSACH/Model/aivenDbConnection.php'; // Đưa mã kết nối CSDL vào

// Kiểm tra xem người dùng đã đăng nhập chưa
if(!isset($_SESSION['userId'])) {
    header("Location: ../View/login.html");
    exit();
}

// Truy vấn CSDL để lấy 5 bản ghi sách
$query = "SELECT * FROM Sach LIMIT 5";
$stmt = $db->query($query);
$sachList = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Danh sách sách</title>
    <style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    table,
    th,
    td {
        border: 1px solid black;
        padding: 8px;
    }

    th {
        background-color: #f2f2f2;
    }
    </style>
</head>

<body>
    <h2>Danh sách sách</h2>
    <table>
        <tr>
            <th>Mã Sách</th>
            <th>Tên Sách</th>
            <th>Số Lượng</th>
        </tr>
        <?php foreach ($sachList as $sach) { ?>
        <tr>
            <td><?php echo $sach['MaSach']; ?></td>
            <td><?php echo $sach['TenSach']; ?></td>
            <td><?php echo $sach['SoLuong']; ?></td>
        </tr>
        <?php } ?>
    </table>

    <br>
    <form action="../Controller/logout.php" method="post">
        <input type="submit" value="Logout">
    </form>
</body>

</html>